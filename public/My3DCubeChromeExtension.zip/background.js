// My-3D-Cube - Chrome Video Sync Background Service Worker

let streamState = {
  isStreaming: false,
  tabId: null,
  tabTitle: '',
  faceIndex: 0,
  bridgeUrl: 'http://127.0.0.1:48124',
  targetMode: 'desktop' // 'desktop' or 'web'
};

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT']
  });

  if (existingContexts && existingContexts.length > 0) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA', 'WEB_RTC'],
    justification: 'Capture tab video to stream directly onto 3D Cube face'
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'START_STREAM') {
    handleStartStream(message)
      .then((res) => sendResponse({ success: true, ...res }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // Keep channel open for async response
  }

  if (message.action === 'STOP_STREAM') {
    handleStopStream()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.action === 'GET_STATUS') {
    sendResponse({ success: true, ...streamState });
    return false;
  }
});

async function handleStartStream({ tabId, tabTitle, faceIndex, bridgeUrl, targetMode }) {
  try {
    const targetTabId = tabId || (await getActiveTabId());
    if (!targetTabId) throw new Error('No active tab found.');

    const activeTab = await chrome.tabs.get(targetTabId);
    const title = tabTitle || activeTab.title || 'Playing Video';

    // 1. Get media stream ID for the target tab
    const streamId = await chrome.tabCapture.getMediaStreamId({
      targetTabId: targetTabId
    });

    if (!streamId) {
      throw new Error('Failed to acquire tab capture stream ID.');
    }

    // 2. Ensure the offscreen capture document is active
    await ensureOffscreenDocument();

    const config = {
      streamId,
      tabId: targetTabId,
      tabTitle: title,
      faceIndex: faceIndex ?? 0,
      bridgeUrl: bridgeUrl || 'http://127.0.0.1:48124',
      targetMode: targetMode || 'desktop'
    };

    // 3. Dispatch to offscreen document to initiate WebRTC capture
    const response = await chrome.runtime.sendMessage({
      action: 'OFFSCREEN_START_CAPTURE',
      ...config
    });

    if (!response || !response.success) {
      throw new Error(response?.error || 'Offscreen document failed to initiate stream.');
    }

    // 4. Update state and badge
    streamState = {
      isStreaming: true,
      tabId: targetTabId,
      tabTitle: title,
      faceIndex: config.faceIndex,
      bridgeUrl: config.bridgeUrl,
      targetMode: config.targetMode
    };

    chrome.action.setBadgeText({ text: 'LIVE' });
    chrome.action.setBadgeBackgroundColor({ color: '#00f0ff' });

    return streamState;
  } catch (err) {
    console.error('[My3DCube Sync] Error in handleStartStream:', err);
    throw err;
  }
}

async function handleStopStream() {
  try {
    // Notify offscreen document
    await chrome.runtime.sendMessage({ action: 'OFFSCREEN_STOP_CAPTURE' }).catch(() => {});

    // Notify local desktop wallpaper bridge to restore normal photo gallery
    if (streamState.bridgeUrl) {
      fetch(`${streamState.bridgeUrl}/api/stream/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faceIndex: streamState.faceIndex })
      }).catch(() => {});
    }

    streamState = {
      isStreaming: false,
      tabId: null,
      tabTitle: '',
      faceIndex: 0,
      bridgeUrl: streamState.bridgeUrl,
      targetMode: streamState.targetMode
    };

    chrome.action.setBadgeText({ text: '' });

    // Close offscreen document
    chrome.offscreen.closeDocument().catch(() => {});
  } catch (err) {
    console.warn('[My3DCube Sync] Error stopping stream:', err);
  }
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

// Auto-stop if the streaming tab is closed
chrome.tabs.onRemoved.addListener((closedTabId) => {
  if (streamState.isStreaming && streamState.tabId === closedTabId) {
    console.log('[My3DCube Sync] Streaming tab closed, shutting down stream.');
    handleStopStream();
  }
});
