// My-3D-Cube - Chrome Video Sync Background Service Worker

let streamState = {
  isStreaming: false,
  tabId: null,
  tabTitle: '',
  faceIndex: -1,
  allFaces: true,
  bridgeUrl: 'http://127.0.0.1:48124',
  targetMode: 'network' // 'network', 'desktop', or 'web'
};

async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT']
  });

  if (existingContexts && existingContexts.length > 0) {
    return;
  }

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA', 'WEB_RTC'],
    justification: 'Capture tab video to stream directly onto 3D Cube face'
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'START_STREAM') {
    handleStartStream(message)
      .then((res) => sendResponse({ success: true, ...res }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // Keep channel open for async response
  }

  if (message.action === 'STOP_STREAM' || message.action === 'RESET_STREAM') {
    handleStopStream()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.action === 'GET_STATUS') {
    sendResponse({ success: true, ...streamState });
    return false;
  }
});

async function handleStartStream({ tabId, tabTitle, faceIndex, allFaces, bridgeUrl, targetMode, monitorIndex }) {
  // Always perform a thorough cleanup of any prior session first
  await handleStopStream();
  await new Promise((resolve) => setTimeout(resolve, 250));

  try {
    const targetTabId = tabId || (await getActiveTabId());
    if (!targetTabId) throw new Error('No active tab found.');

    const activeTab = await chrome.tabs.get(targetTabId);
    const title = tabTitle || activeTab?.title || 'Playing Video';

    // 1. Get media stream ID for the target tab with active-stream auto-recovery
    let streamId = null;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({
        targetTabId: targetTabId
      });
    } catch (streamErr) {
      if (streamErr.message && streamErr.message.includes('active stream')) {
        console.warn('[My3DCube Sync] Active stream detected on tab. Resetting offscreen document...');
        await handleStopStream();
        await new Promise((resolve) => setTimeout(resolve, 500));
        streamId = await chrome.tabCapture.getMediaStreamId({
          targetTabId: targetTabId
        });
      } else {
        throw streamErr;
      }
    }

    if (!streamId) {
      throw new Error('Failed to acquire tab capture stream ID.');
    }

    // 2. Ensure the offscreen capture document is active
    await ensureOffscreenDocument();

    const config = {
      streamId,
      tabId: targetTabId,
      tabTitle: title,
      faceIndex: faceIndex ?? -1,
      allFaces: allFaces !== false,
      bridgeUrl: bridgeUrl || 'http://127.0.0.1:48124',
      targetMode: targetMode || 'desktop',
      monitorIndex: monitorIndex || 'all'
    };

    // 3. Dispatch to offscreen document to initiate WebRTC capture
    const response = await chrome.runtime.sendMessage({
      action: 'OFFSCREEN_START_CAPTURE',
      ...config
    });

    if (!response || !response.success) {
      throw new Error(response?.error || 'Offscreen document failed to initiate stream.');
    }

    // 4. Update state and badge
    streamState = {
      isStreaming: true,
      tabId: targetTabId,
      tabTitle: title,
      faceIndex: config.faceIndex,
      allFaces: config.allFaces,
      bridgeUrl: config.bridgeUrl,
      targetMode: config.targetMode,
      monitorIndex: config.monitorIndex
    };

    chrome.action.setBadgeText({ text: 'LIVE' });
    chrome.action.setBadgeBackgroundColor({ color: '#00f0ff' });

    return streamState;
  } catch (err) {
    console.error('[My3DCube Sync] Error in handleStartStream:', err);
    await handleStopStream();
    throw err;
  }
}

async function handleStopStream() {
  try {
    // Notify offscreen document
    await chrome.runtime.sendMessage({ action: 'OFFSCREEN_STOP_CAPTURE' }).catch(() => {});

    // Notify local desktop wallpaper bridge to restore normal photo gallery
    if (streamState.bridgeUrl) {
      fetch(`${streamState.bridgeUrl}/api/stream/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faceIndex: streamState.faceIndex, monitorIndex: -1 })
      }).catch(() => {});

      fetch(`${streamState.bridgeUrl}/api/stream/broadcast/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ faceIndex: streamState.faceIndex })
      }).catch(() => {});
    }

    // Notify central Rails API that broadcast ended
    fetch('http://162.35.101.183:3000/api/v1/stream/cast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: false })
    }).catch(() => {});

    // Notify all tabs that casting stopped
    chrome.tabs.query({}, (tabs) => {
      if (tabs && tabs.length > 0) {
        tabs.forEach((t) => {
          chrome.tabs.sendMessage(t.id, { action: 'STREAM_STOPPED' }).catch(() => {});
        });
      }
    });

    streamState.isStreaming = false;
    streamState.tabId = null;
    streamState.tabTitle = '';
    streamState.monitorIndex = 'all';
    chrome.action.setBadgeText({ text: '' });

    // Ensure all offscreen documents are closed to release the tab capture lock
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT']
    });
    if (existingContexts && existingContexts.length > 0) {
      await chrome.offscreen.closeDocument().catch(() => {});
    }
  } catch (err) {
    console.warn('[My3DCube Sync] Error stopping stream:', err);
  }
}

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}

// Auto-stop if the streaming tab is closed
chrome.tabs.onRemoved.addListener((closedTabId) => {
  if (streamState.isStreaming && streamState.tabId === closedTabId) {
    console.log('[My3DCube Sync] Streaming tab closed, shutting down stream.');
    handleStopStream();
  }
});
