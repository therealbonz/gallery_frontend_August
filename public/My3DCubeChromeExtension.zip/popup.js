// My-3D-Cube - Popup UI Controller

document.addEventListener('DOMContentLoaded', async () => {
  const tabTitleEl = document.getElementById('tabTitle');
  const faceSelectEl = document.getElementById('faceSelect');
  const targetModeEl = document.getElementById('targetMode');
  const statusBadgeEl = document.getElementById('statusBadge');
  const statusDotEl = document.getElementById('statusDot');
  const statusTextEl = document.getElementById('statusText');
  const btnCastEl = document.getElementById('btnCast');
  const btnCastTextEl = document.getElementById('btnCastText');

  let activeTab = null;
  let isCurrentlyStreaming = false;

  // 1. Get current active tab
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTab = tab;
    tabTitleEl.textContent = tab?.title || 'Unknown Tab';
  } catch (e) {
    tabTitleEl.textContent = 'Active Chrome Tab';
  }

  // 2. Query current streaming status from background service worker
  chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (res) => {
    if (res && res.isStreaming) {
      setStreamingUI(res.faceIndex, res.targetMode);
    } else {
      setIdleUI();
    }
  });

  // 3. Handle Cast / Stop Toggle
  btnCastEl.addEventListener('click', async () => {
    if (isCurrentlyStreaming) {
      // Stop Stream
      btnCastEl.disabled = true;
      btnCastTextEl.textContent = 'Stopping...';
      chrome.runtime.sendMessage({ action: 'STOP_STREAM' }, () => {
        btnCastEl.disabled = false;
        setIdleUI();
      });
    } else {
      // Start Stream
      btnCastEl.disabled = true;
      btnCastTextEl.textContent = 'Connecting...';

      const faceIndex = parseInt(faceSelectEl.value, 10);
      const targetMode = targetModeEl.value;
      const bridgeUrl = targetMode === 'desktop' ? 'http://127.0.0.1:48124' : 'http://162.35.101.183:5173';

      chrome.runtime.sendMessage(
        {
          action: 'START_STREAM',
          tabId: activeTab?.id,
          tabTitle: activeTab?.title,
          faceIndex,
          bridgeUrl,
          targetMode
        },
        (response) => {
          btnCastEl.disabled = false;
          if (response && response.success) {
            setStreamingUI(faceIndex, targetMode);
          } else {
            alert('Failed to start stream: ' + (response?.error || 'Unknown error'));
            setIdleUI();
          }
        }
      );
    }
  });

  function setStreamingUI(faceIndex, targetMode) {
    isCurrentlyStreaming = true;
    if (faceIndex !== undefined) faceSelectEl.value = faceIndex;
    if (targetMode !== undefined) targetModeEl.value = targetMode;

    faceSelectEl.disabled = true;
    targetModeEl.disabled = true;

    statusBadgeEl.className = 'status-badge streaming';
    statusDotEl.className = 'status-dot pulse';
    statusTextEl.textContent = `🔴 STREAMING LIVE to Face ${faceIndex ?? 0}`;

    btnCastEl.className = 'btn-action btn-stop';
    btnCastTextEl.textContent = '⏹️ Stop Casting to 3D Cube';
  }

  function setIdleUI() {
    isCurrentlyStreaming = false;
    faceSelectEl.disabled = false;
    targetModeEl.disabled = false;

    statusBadgeEl.className = 'status-badge idle';
    statusDotEl.className = 'status-dot';
    statusTextEl.textContent = 'Ready to Cast';

    btnCastEl.className = 'btn-action btn-cast';
    btnCastTextEl.textContent = '🎬 Cast Video to 3D Cube';
  }
});
