// My-3D-Cube - Popup UI Controller

document.addEventListener('DOMContentLoaded', async () => {
  const tabTitleEl = document.getElementById('tabTitle');
  const faceSelectEl = document.getElementById('faceSelect');
  const targetModeEl = document.getElementById('targetMode');
  const monitorSelectEl = document.getElementById('monitorSelect');
  const monitorGroupEl = document.getElementById('monitorGroup');
  const statusBadgeEl = document.getElementById('statusBadge');
  const statusDotEl = document.getElementById('statusDot');
  const statusTextEl = document.getElementById('statusText');
  const btnCastEl = document.getElementById('btnCast');
  const btnCastTextEl = document.getElementById('btnCastText');

  let activeTab = null;
  let isCurrentlyStreaming = false;

  // 1. Get current active tab
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    activeTab = tab;
    tabTitleEl.textContent = tab?.title || 'Unknown Tab';
  } catch (e) {
    tabTitleEl.textContent = 'Active Chrome Tab';
  }

  // 1.5 Load connected monitors from desktop wallpaper bridge
  async function loadMonitors() {
    try {
      const res = await fetch('http://127.0.0.1:48124/api/monitors', { signal: AbortSignal.timeout(1500) });
      if (res.ok) {
        const data = await res.json();
        if (data && data.monitors && data.monitors.length > 0) {
          monitorSelectEl.innerHTML = '<option value="all" selected>🌟 All Displays (Sync All Cubes)</option>';
          data.monitors.forEach((m) => {
            const opt = document.createElement('option');
            opt.value = m.index;
            opt.textContent = `🖥️ ${m.name}`;
            monitorSelectEl.appendChild(opt);
          });
        }
      }
    } catch (e) {
      console.warn('[My3DCube] Could not load monitors from bridge:', e);
    }
  }

  targetModeEl.addEventListener('change', () => {
    if (targetModeEl.value === 'desktop') {
      if (monitorGroupEl) monitorGroupEl.style.display = 'flex';
      loadMonitors();
    } else {
      if (monitorGroupEl) monitorGroupEl.style.display = 'none';
    }
  });

  // Default to hiding monitor select if network mode is selected
  if (targetModeEl.value !== 'desktop' && monitorGroupEl) {
    monitorGroupEl.style.display = 'none';
  }

  await loadMonitors();

  // 2. Query current streaming status from background service worker
  chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (res) => {
    if (res && res.isStreaming) {
      setStreamingUI(res.faceIndex, res.targetMode, res.monitorIndex);
    } else {
      setIdleUI();
    }
  });

  // 2.5 Force Reset Handler
  const btnResetEl = document.getElementById('btnReset');
  if (btnResetEl) {
    btnResetEl.addEventListener('click', (e) => {
      e.preventDefault();
      btnResetEl.textContent = 'Resetting...';
      chrome.runtime.sendMessage({ action: 'RESET_STREAM' }, () => {
        btnResetEl.textContent = '🔄 Force Reset / Clear Stream';
        setIdleUI();
      });
    });
  }

  // 3. Handle Cast / Stop Toggle
  btnCastEl.addEventListener('click', async () => {
    if (isCurrentlyStreaming) {
      // Stop Stream
      btnCastEl.disabled = true;
      btnCastTextEl.textContent = 'Stopping...';
      chrome.runtime.sendMessage({ action: 'STOP_STREAM' }, () => {
        btnCastEl.disabled = false;
        setIdleUI();
      });
    } else {
      // Start Stream
      btnCastEl.disabled = true;
      btnCastTextEl.textContent = 'Connecting...';

      const faceVal = faceSelectEl.value;
      const faceIndex = faceVal === 'all' ? -1 : parseInt(faceVal, 10);
      const allFaces = faceVal === 'all';
      const targetMode = targetModeEl.value;
      const monitorIndex = monitorSelectEl ? monitorSelectEl.value : 'all';
      const bridgeUrl = (targetMode === 'desktop' || targetMode === 'network') ? 'http://127.0.0.1:48124' : 'http://162.35.101.183:5173';

      chrome.runtime.sendMessage(
        {
          action: 'START_STREAM',
          tabId: activeTab?.id,
          tabTitle: activeTab?.title,
          faceIndex,
          allFaces,
          bridgeUrl,
          targetMode,
          monitorIndex
        },
        (response) => {
          btnCastEl.disabled = false;
          if (response && response.success) {
            setStreamingUI(faceVal, targetMode, monitorIndex);
          } else {
            alert('Failed to start stream: ' + (response?.error || 'Unknown error'));
            setIdleUI();
          }
        }
      );
    }
  });

  function setStreamingUI(faceVal, targetMode, monitorIndex) {
    isCurrentlyStreaming = true;
    if (faceVal !== undefined) faceSelectEl.value = faceVal;
    if (targetMode !== undefined) targetModeEl.value = targetMode;
    if (monitorIndex !== undefined && monitorSelectEl) monitorSelectEl.value = monitorIndex;

    faceSelectEl.disabled = true;
    targetModeEl.disabled = true;
    if (monitorSelectEl) monitorSelectEl.disabled = true;

    statusBadgeEl.className = 'status-badge streaming';
    statusDotEl.className = 'status-dot pulse';
    const monLabel = monitorIndex === 'all' || !monitorIndex ? 'All Displays' : `Display ${parseInt(monitorIndex) + 1}`;
    const faceLabel = faceVal === 'all' || faceVal === undefined || faceVal === -1 ? 'All 6 Faces' : `Face ${faceVal}`;
    const modeLabel = targetMode === 'network' ? 'All Network PCs & Androids' : (targetMode === 'desktop' ? `Local Desktop (${monLabel})` : 'Web Gallery');
    statusTextEl.textContent = `🔴 STREAMING LIVE to ${faceLabel} - ${modeLabel}`;

    btnCastEl.className = 'btn-action btn-stop';
    btnCastTextEl.textContent = '⏹️ Stop Casting to 3D Cube';
  }

  function setIdleUI() {
    isCurrentlyStreaming = false;
    faceSelectEl.disabled = false;
    targetModeEl.disabled = false;
    if (monitorSelectEl) monitorSelectEl.disabled = false;

    statusBadgeEl.className = 'status-badge idle';
    statusDotEl.className = 'status-dot';
    statusTextEl.textContent = 'Ready to Cast';

    btnCastEl.className = 'btn-action btn-cast';
    btnCastTextEl.textContent = '🎬 Cast Video to 3D Cube';
  }
});
