// My-3D-Cube - Offscreen Stream Capture & Multi-Peer WebRTC Broadcast

let currentStream = null;
let currentAudioContext = null;
let peerConnections = []; // Array of { pc, monitorIndex }
let networkPeers = new Map(); // clientId => { pc, clientId }
let currentBridgeUrl = null;
let isBroadcasting = false;
let broadcasterPollTimer = null;
let activeConfig = null;

const CENTRAL_API_URL = 'http://162.35.101.183:3000/api/v1';

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OFFSCREEN_START_CAPTURE') {
    startCapture(message)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }

  if (message.action === 'OFFSCREEN_STOP_CAPTURE') {
    stopCapture();
    sendResponse({ success: true });
    return false;
  }
});

async function startCapture(config) {
  stopCapture(); // Clean up any active session first
  activeConfig = config;
  const { streamId, faceIndex, allFaces, bridgeUrl, monitorIndex, targetMode, tabTitle } = config;
  currentBridgeUrl = bridgeUrl || 'http://127.0.0.1:48124';

  try {
    // 1. Acquire Tab Stream (Audio + Video) via Chromium MediaSource
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId,
          maxFrameRate: 60
        }
      }
    });

    currentStream = stream;

    // 2. Tab Audio Passthrough:
    // Capturing audio directly through tabCapture will mute the original tab.
    // Connect stream audio to AudioContext destination so sound plays through user speakers!
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const audioSource = audioCtx.createMediaStreamSource(stream);
      audioSource.connect(audioCtx.destination);
      currentAudioContext = audioCtx;
    } catch (audioErr) {
      console.warn('[My3DCube Sync] Audio passthrough initialization warning:', audioErr);
    }

    const videoTrack = stream.getVideoTracks()[0];
    if (!videoTrack) {
      throw new Error('No video track found in captured tab.');
    }

    const safeFaceIndex = (faceIndex === 'all' || faceIndex === -1 || faceIndex === undefined) ? -1 : faceIndex;

    // 3. Connect to Local Desktop Bridge monitors (if available)
    if (targetMode === 'desktop' || targetMode === 'network' || targetMode === undefined) {
      let targetMonitors = [];
      if (monitorIndex === 'all' || monitorIndex === undefined || monitorIndex === null || monitorIndex === -1) {
        try {
          const monRes = await fetch(`${currentBridgeUrl}/api/monitors`, { signal: AbortSignal.timeout(1500) });
          if (monRes.ok) {
            const data = await monRes.json();
            if (data && data.monitors && data.monitors.length > 0) {
              targetMonitors = data.monitors.map((m) => m.index);
            }
          }
        } catch (e) {
          console.warn('[My3DCube Sync] Could not fetch local monitor list:', e);
        }
        if (targetMonitors.length === 0) {
          targetMonitors = [0];
        }
      } else {
        targetMonitors = [parseInt(monitorIndex, 10)];
      }

      console.log('[My3DCube Sync] Attempting local bridge connection for monitors:', targetMonitors);

      await Promise.all(targetMonitors.map(async (mIdx) => {
        try {
          const pc = new RTCPeerConnection({ iceServers: [] });
          pc.addTrack(videoTrack, stream);

          pc.onicecandidate = (event) => {
            if (event.candidate && currentBridgeUrl) {
              fetch(`${currentBridgeUrl}/api/stream/candidate`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  candidate: event.candidate,
                  faceIndex: safeFaceIndex,
                  monitorIndex: mIdx
                })
              }).catch(() => {});
            }
          };

          const offer = await pc.createOffer({
            offerToReceiveAudio: false,
            offerToReceiveVideo: true
          });
          await pc.setLocalDescription(offer);

          await waitForIce(pc, 200);
          const offerSdp = pc.localDescription?.sdp || offer.sdp;

          const response = await fetch(`${currentBridgeUrl}/api/stream/offer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              type: offer.type,
              sdp: offerSdp,
              faceIndex: safeFaceIndex,
              allFaces: allFaces !== false,
              monitorIndex: mIdx
            }),
            signal: AbortSignal.timeout(4000)
          });

          if (response.ok) {
            const answerData = await response.json();
            if (answerData && answerData.sdp) {
              await pc.setRemoteDescription(new RTCSessionDescription({
                type: answerData.type || 'answer',
                sdp: answerData.sdp
              }));
              console.log(`[My3DCube Sync] WebRTC connected to Monitor ${mIdx}`);
              peerConnections.push({ pc, monitorIndex: mIdx });
            }
          }
        } catch (monErr) {
          console.warn(`[My3DCube Sync] Local monitor ${mIdx} connection notice:`, monErr.message);
        }
      }));
    }

    // 4. Start Network Broadcast (Announce to LAN bridge & Central Rails API)
    if (targetMode === 'network' || targetMode === 'web' || targetMode === undefined) {
      await startNetworkBroadcasting({
        streamId: `stream_${Date.now()}`,
        faceIndex: safeFaceIndex,
        allFaces: allFaces !== false,
        title: tabTitle || 'Chrome Video Sync'
      });
    }

    // Ensure we have at least one active connection or active network broadcast
    if (peerConnections.length === 0 && !isBroadcasting) {
      throw new Error('Failed to connect to any display target.');
    }

    console.log('[My3DCube Sync] Streaming active. Local peers:', peerConnections.length, 'Network broadcast:', isBroadcasting);
  } catch (err) {
    console.error('[My3DCube Sync] startCapture failed:', err);
    stopCapture();
    throw err;
  }
}

async function startNetworkBroadcasting({ streamId, faceIndex, allFaces, title }) {
  isBroadcasting = true;

  const broadcastPayload = {
    active: true,
    stream_id: streamId,
    title: title,
    face_index: faceIndex,
    all_faces: allFaces,
    timestamp: Date.now()
  };

  // Announce to local bridge
  if (currentBridgeUrl) {
    fetch(`${currentBridgeUrl}/api/stream/broadcast/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        streamId,
        title,
        faceIndex,
        allFaces
      })
    }).catch(() => {});
  }

  // Announce to Central Rails API
  try {
    await fetch(`${CENTRAL_API_URL}/stream/cast`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(broadcastPayload),
      signal: AbortSignal.timeout(3000)
    });
    console.log('[My3DCube Sync] Network broadcast announced to Central API successfully!');
  } catch (e) {
    console.warn('[My3DCube Sync] Central API broadcast announcement warning:', e.message);
  }

  // Start polling for network clients joining the stream
  if (broadcasterPollTimer) clearInterval(broadcasterPollTimer);
  broadcasterPollTimer = setInterval(pollBroadcasterSignals, 800);
}

async function pollBroadcasterSignals() {
  if (!isBroadcasting || !currentStream) return;

  const endpoints = [];
  endpoints.push(`${CENTRAL_API_URL}/stream/signals?receiver_id=broadcaster`);
  if (currentBridgeUrl) {
    endpoints.push(`${currentBridgeUrl}/api/stream/signals?receiver_id=broadcaster`);
  }

  for (const url of endpoints) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(1200) });
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.signals) && data.signals.length > 0) {
          for (const sig of data.signals) {
            await handleIncomingSignal(sig);
          }
        }
      }
    } catch (e) {
      // Periodic poll warning ignored
    }
  }
}

async function handleIncomingSignal(sig) {
  const { sender_id, type, payload } = sig;
  if (!sender_id || !currentStream) return;

  const videoTrack = currentStream.getVideoTracks()[0];
  if (!videoTrack) return;

  if (type === 'join') {
    console.log(`[My3DCube Sync] Network client '${sender_id}' requested to join stream.`);
    // Client wants to receive video
    // Close prior connection if existing
    const existing = networkPeers.get(sender_id);
    if (existing) {
      try { existing.pc.close(); } catch (e) {}
      networkPeers.delete(sender_id);
    }

    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });

    pc.addTrack(videoTrack, currentStream);

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendSignalToClient(sender_id, 'candidate', event.candidate);
      }
    };

    pc.onconnectionstatechange = () => {
      console.log(`[My3DCube Sync] Peer connection to '${sender_id}':`, pc.connectionState);
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        try { pc.close(); } catch (e) {}
        networkPeers.delete(sender_id);
      }
    };

    networkPeers.set(sender_id, { pc, clientId: sender_id });

    // Create and send SDP Offer to client
    const offer = await pc.createOffer({
      offerToReceiveAudio: false,
      offerToReceiveVideo: true
    });
    await pc.setLocalDescription(offer);
    await waitForIce(pc, 250);

    const offerSdp = pc.localDescription?.sdp || offer.sdp;
    await sendSignalToClient(sender_id, 'offer', {
      type: offer.type,
      sdp: offerSdp,
      faceIndex: activeConfig?.faceIndex ?? -1,
      allFaces: activeConfig?.allFaces !== false
    });
  } else if (type === 'answer') {
    const peer = networkPeers.get(sender_id);
    if (peer && peer.pc && payload && payload.sdp) {
      console.log(`[My3DCube Sync] Received WebRTC answer from '${sender_id}'`);
      await peer.pc.setRemoteDescription(new RTCSessionDescription({
        type: payload.type || 'answer',
        sdp: payload.sdp
      })).catch((err) => console.warn(`Error setting remote description for ${sender_id}:`, err));
    }
  } else if (type === 'candidate') {
    const peer = networkPeers.get(sender_id);
    if (peer && peer.pc && payload) {
      await peer.pc.addIceCandidate(new RTCIceCandidate(payload)).catch(() => {});
    }
  } else if (type === 'leave') {
    const peer = networkPeers.get(sender_id);
    if (peer) {
      try { peer.pc.close(); } catch (e) {}
      networkPeers.delete(sender_id);
    }
  }
}

async function sendSignalToClient(targetClientId, signalType, payload) {
  const body = JSON.stringify({
    target: targetClientId,
    sender_id: 'broadcaster',
    type: signalType,
    payload: payload
  });

  const endpoints = [
    `${CENTRAL_API_URL}/stream/signal`,
    ...(currentBridgeUrl ? [`${currentBridgeUrl}/api/stream/signal`] : [])
  ];

  await Promise.all(endpoints.map((url) =>
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body,
      signal: AbortSignal.timeout(2000)
    }).catch(() => {})
  ));
}

function stopCapture() {
  if (broadcasterPollTimer) {
    clearInterval(broadcasterPollTimer);
    broadcasterPollTimer = null;
  }

  // Notify network peers of stop
  if (isBroadcasting) {
    fetch(`${CENTRAL_API_URL}/stream/cast`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: false })
    }).catch(() => {});

    if (currentBridgeUrl) {
      fetch(`${currentBridgeUrl}/api/stream/broadcast/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ active: false })
      }).catch(() => {});
    }
  }

  isBroadcasting = false;

  // Close all network peer connections
  if (networkPeers.size > 0) {
    for (const [id, peer] of networkPeers.entries()) {
      try { peer.pc.close(); } catch (e) {}
    }
    networkPeers.clear();
  }

  // Close local bridge peer connections
  if (peerConnections && peerConnections.length > 0) {
    for (const item of peerConnections) {
      try { item.pc.close(); } catch (e) {}
    }
    peerConnections = [];
  }

  if (currentStream) {
    try {
      currentStream.getTracks().forEach((t) => t.stop());
    } catch (e) {}
    currentStream = null;
  }

  if (currentAudioContext) {
    try {
      currentAudioContext.close();
    } catch (e) {}
    currentAudioContext = null;
  }
}

function waitForIce(pc, timeoutMs = 250) {
  return new Promise((resolve) => {
    if (pc.iceGatheringState === 'complete') {
      resolve();
      return;
    }
    const check = () => {
      if (pc.iceGatheringState === 'complete') {
        pc.removeEventListener('icegatheringstatechange', check);
        resolve();
      }
    };
    pc.addEventListener('icegatheringstatechange', check);
    setTimeout(resolve, timeoutMs);
  });
}
