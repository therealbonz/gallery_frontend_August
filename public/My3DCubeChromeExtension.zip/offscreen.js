// My-3D-Cube - Offscreen Stream Capture & WebRTC Peer Connection

let currentStream = null;
let currentAudioContext = null;
let peerConnection = null;
let currentBridgeUrl = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OFFSCREEN_START_CAPTURE') {
    startCapture(message)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }

  if (message.action === 'OFFSCREEN_STOP_CAPTURE') {
    stopCapture();
    sendResponse({ success: true });
    return false;
  }
});

async function startCapture({ streamId, faceIndex, bridgeUrl }) {
  stopCapture(); // Clean up any active session first
  currentBridgeUrl = bridgeUrl;

  try {
    // 1. Acquire Tab Stream (Audio + Video) via Chromium MediaSource
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId,
          maxFrameRate: 60
        }
      }
    });

    currentStream = stream;

    // 2. Tab Audio Passthrough:
    // Capturing audio directly through tabCapture will mute the original tab.
    // Connect stream audio to AudioContext destination so sound plays through user speakers!
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const audioSource = audioCtx.createMediaStreamSource(stream);
      audioSource.connect(audioCtx.destination);
      currentAudioContext = audioCtx;
    } catch (audioErr) {
      console.warn('[My3DCube Sync] Audio passthrough initialization warning:', audioErr);
    }

    // 3. Setup WebRTC Peer Connection
    // Since this connects directly to the local desktop wallpaper (127.0.0.1), no STUN servers required.
    const pc = new RTCPeerConnection({
      iceServers: []
    });
    peerConnection = pc;

    // Add video track to WebRTC
    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      pc.addTrack(videoTrack, stream);
    }

    // Forward ICE candidates to local bridge
    pc.onicecandidate = (event) => {
      if (event.candidate && currentBridgeUrl) {
        fetch(`${currentBridgeUrl}/api/stream/candidate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            candidate: event.candidate,
            faceIndex: faceIndex
          })
        }).catch(() => {});
      }
    };

    // Create SDP Offer
    const offer = await pc.createOffer({
      offerToReceiveAudio: false,
      offerToReceiveVideo: true
    });
    await pc.setLocalDescription(offer);

    // Wait briefly for local host candidates to gather so offer SDP has connection routes
    await new Promise((resolve) => {
      if (pc.iceGatheringState === 'complete') {
        resolve();
      } else {
        const check = () => {
          if (pc.iceGatheringState === 'complete') {
            pc.removeEventListener('icegatheringstatechange', check);
            resolve();
          }
        };
        pc.addEventListener('icegatheringstatechange', check);
        setTimeout(resolve, 200);
      }
    });

    const offerSdp = pc.localDescription?.sdp || offer.sdp;

    // 4. Send Offer to Local Bridge (Desktop Wallpaper on 127.0.0.1:48124)
    const response = await fetch(`${currentBridgeUrl}/api/stream/offer`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: offer.type,
        sdp: offerSdp,
        faceIndex: faceIndex ?? 0
      })
    });

    if (!response.ok) {
      throw new Error(`Bridge returned HTTP ${response.status}: ${await response.text()}`);
    }

    const answerData = await response.json();
    if (!answerData || !answerData.sdp) {
      throw new Error('Invalid SDP answer received from 3D Cube wallpaper bridge.');
    }

    // Set Remote Description (Answer)
    await pc.setRemoteDescription(new RTCSessionDescription({
      type: answerData.type || 'answer',
      sdp: answerData.sdp
    }));

    console.log('[My3DCube Sync] WebRTC connection established with 3D Cube face', faceIndex);
  } catch (err) {
    console.error('[My3DCube Sync] startCapture failed:', err);
    stopCapture();
    throw err;
  }
}

function stopCapture() {
  if (peerConnection) {
    try {
      peerConnection.close();
    } catch (e) {}
    peerConnection = null;
  }

  if (currentStream) {
    try {
      currentStream.getTracks().forEach((t) => t.stop());
    } catch (e) {}
    currentStream = null;
  }

  if (currentAudioContext) {
    try {
      currentAudioContext.close();
    } catch (e) {}
    currentAudioContext = null;
  }
}
