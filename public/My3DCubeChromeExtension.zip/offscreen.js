// My-3D-Cube - Offscreen Stream Capture & WebRTC Peer Connection

let currentStream = null;
let currentAudioContext = null;
let peerConnections = []; // Array of { pc, monitorIndex }
let currentBridgeUrl = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OFFSCREEN_START_CAPTURE') {
    startCapture(message)
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // async response
  }

  if (message.action === 'OFFSCREEN_STOP_CAPTURE') {
    stopCapture();
    sendResponse({ success: true });
    return false;
  }
});

async function startCapture({ streamId, faceIndex, bridgeUrl, monitorIndex, targetMode }) {
  stopCapture(); // Clean up any active session first
  currentBridgeUrl = bridgeUrl;

  try {
    // 1. Acquire Tab Stream (Audio + Video) via Chromium MediaSource
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId,
          maxFrameRate: 60
        }
      }
    });

    currentStream = stream;

    // 2. Tab Audio Passthrough:
    // Capturing audio directly through tabCapture will mute the original tab.
    // Connect stream audio to AudioContext destination so sound plays through user speakers!
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const audioSource = audioCtx.createMediaStreamSource(stream);
      audioSource.connect(audioCtx.destination);
      currentAudioContext = audioCtx;
    } catch (audioErr) {
      console.warn('[My3DCube Sync] Audio passthrough initialization warning:', audioErr);
    }

    const videoTrack = stream.getVideoTracks()[0];
    if (!videoTrack) {
      throw new Error('No video track found in captured tab.');
    }

    // 3. Determine target monitors
    let targetMonitors = [];
    if (targetMode === 'web') {
      targetMonitors = [-1]; // Web Gallery
    } else if (monitorIndex === 'all' || monitorIndex === undefined || monitorIndex === null) {
      try {
        const monRes = await fetch(`${bridgeUrl}/api/monitors`, { signal: AbortSignal.timeout(1500) });
        if (monRes.ok) {
          const data = await monRes.json();
          if (data && data.monitors && data.monitors.length > 0) {
            targetMonitors = data.monitors.map((m) => m.index);
          }
        }
      } catch (e) {
        console.warn('[My3DCube Sync] Could not fetch monitor list:', e);
      }
      if (targetMonitors.length === 0) {
        targetMonitors = [0, 1, 2];
      }
    } else {
      targetMonitors = [parseInt(monitorIndex, 10)];
    }

    console.log('[My3DCube Sync] Initiating WebRTC for monitors:', targetMonitors);

    // 4. Create WebRTC Peer Connections for each target monitor
    for (const mIdx of targetMonitors) {
      try {
        const pc = new RTCPeerConnection({ iceServers: [] });

        pc.addTrack(videoTrack, stream);

        // Forward ICE candidates to local bridge with monitorIndex
        pc.onicecandidate = (event) => {
          if (event.candidate && currentBridgeUrl) {
            fetch(`${currentBridgeUrl}/api/stream/candidate`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                candidate: event.candidate,
                faceIndex: faceIndex ?? 0,
                monitorIndex: mIdx
              })
            }).catch(() => {});
          }
        };

        // Create SDP Offer
        const offer = await pc.createOffer({
          offerToReceiveAudio: false,
          offerToReceiveVideo: true
        });
        await pc.setLocalDescription(offer);

        // Wait briefly for local host candidates to gather
        await new Promise((resolve) => {
          if (pc.iceGatheringState === 'complete') {
            resolve();
          } else {
            const check = () => {
              if (pc.iceGatheringState === 'complete') {
                pc.removeEventListener('icegatheringstatechange', check);
                resolve();
              }
            };
            pc.addEventListener('icegatheringstatechange', check);
            setTimeout(resolve, 200);
          }
        });

        const offerSdp = pc.localDescription?.sdp || offer.sdp;

        // Send Offer to Local Bridge
        const response = await fetch(`${currentBridgeUrl}/api/stream/offer`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: offer.type,
            sdp: offerSdp,
            faceIndex: faceIndex ?? 0,
            monitorIndex: mIdx
          })
        });

        if (response.ok) {
          const answerData = await response.json();
          if (answerData && answerData.sdp) {
            await pc.setRemoteDescription(new RTCSessionDescription({
              type: answerData.type || 'answer',
              sdp: answerData.sdp
            }));
            console.log(`[My3DCube Sync] WebRTC connected to Monitor ${mIdx}, face ${faceIndex}`);
            peerConnections.push({ pc, monitorIndex: mIdx });
          }
        } else {
          console.warn(`[My3DCube Sync] Bridge rejected offer for Monitor ${mIdx}:`, response.status);
        }
      } catch (monErr) {
        console.warn(`[My3DCube Sync] Error setting up WebRTC for Monitor ${mIdx}:`, monErr);
      }
    }

    if (peerConnections.length === 0) {
      throw new Error('Failed to establish WebRTC connection with any wallpaper display.');
    }
  } catch (err) {
    console.error('[My3DCube Sync] startCapture failed:', err);
    stopCapture();
    throw err;
  }
}

function stopCapture() {
  if (peerConnections && peerConnections.length > 0) {
    for (const item of peerConnections) {
      try {
        item.pc.close();
      } catch (e) {}
    }
    peerConnections = [];
  }

  if (currentStream) {
    try {
      currentStream.getTracks().forEach((t) => t.stop());
    } catch (e) {}
    currentStream = null;
  }

  if (currentAudioContext) {
    try {
      currentAudioContext.close();
    } catch (e) {}
    currentAudioContext = null;
  }
}
