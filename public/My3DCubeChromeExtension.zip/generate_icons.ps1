Add-Type -AssemblyName System.Drawing

function Create-Icon([int]$size, [string]$path) {
    $bmp = New-Object System.Drawing.Bitmap $size, $size
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::FromArgb(11, 15, 25))
    
    $penWidth = [Math]::Max(1.0, [float]$size / 14.0)
    $pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(0, 240, 255)), $penWidth
    $purpleWidth = [Math]::Max(1.0, [float]$size / 16.0)
    $purplePen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(168, 85, 247)), $purpleWidth
    
    $pad = [float]$size * 0.18
    $midX = [float]$size / 2.0
    $midY = [float]$size / 2.0
    $radius = ([float]$size - (2.0 * $pad)) / 2.0
    
    $topY = $pad
    $bottomY = [float]$size - $pad
    $leftX = $pad
    $rightX = [float]$size - $pad
    
    $yUpper = $midY - ($radius * 0.5)
    $yLower = $midY + ($radius * 0.5)
    
    $top = New-Object System.Drawing.PointF $midX, $topY
    $bottom = New-Object System.Drawing.PointF $midX, $bottomY
    $p1 = New-Object System.Drawing.PointF $leftX, $yUpper
    $p2 = New-Object System.Drawing.PointF $rightX, $yUpper
    $p3 = New-Object System.Drawing.PointF $leftX, $yLower
    $p4 = New-Object System.Drawing.PointF $rightX, $yLower
    $center = New-Object System.Drawing.PointF $midX, $midY
    
    $pts = [System.Drawing.PointF[]]($top, $p2, $p4, $bottom, $p3, $p1)
    $g.DrawPolygon($pen, $pts)
    $g.DrawLine($pen, $center, $top)
    $g.DrawLine($purplePen, $center, $p3)
    $g.DrawLine($purplePen, $center, $p4)
    
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
}

Create-Icon 16 'f:\gallery_chrome_extension\icons\icon16.png'
Create-Icon 48 'f:\gallery_chrome_extension\icons\icon48.png'
Create-Icon 128 'f:\gallery_chrome_extension\icons\icon128.png'
Write-Host 'Generated icon16, icon48, icon128 successfully!'
