// My-3D-Cube - In-Page Video Cast Overlay Button

(function () {
  let castButton = null;

  function findActiveVideo() {
    const videos = Array.from(document.querySelectorAll('video'));
    if (videos.length === 0) return null;
    return videos.find((v) => !v.paused && v.currentTime > 0) || videos[0];
  }

  function injectCastButton() {
    if (document.getElementById('my3dcube-cast-btn')) return;

    // Check if on a video page
    const video = findActiveVideo();
    if (!video) return;

    const btn = document.createElement('button');
    btn.id = 'my3dcube-cast-btn';
    btn.className = 'my3dcube-floating-btn';
    btn.innerHTML = `
      <span class="cube-icon">🎲</span>
      <span class="btn-text">Cast to 3D Cube</span>
    `;

    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();

      btn.classList.add('loading');
      btn.querySelector('.btn-text').textContent = 'Connecting...';

      chrome.runtime.sendMessage(
        {
          action: 'START_STREAM',
          tabTitle: document.title,
          faceIndex: 0,
          bridgeUrl: 'http://127.0.0.1:48124',
          targetMode: 'desktop'
        },
        (res) => {
          btn.classList.remove('loading');
          if (res && res.success) {
            btn.classList.add('streaming');
            btn.querySelector('.btn-text').textContent = '🔴 Casting Live';
          } else {
            btn.querySelector('.btn-text').textContent = 'Cast to 3D Cube';
          }
        }
      );
    });

    document.body.appendChild(btn);
    castButton = btn;
  }

  // Periodic check for video elements on dynamic SPAs (YouTube, Twitch)
  setInterval(() => {
    const video = findActiveVideo();
    if (video && !document.getElementById('my3dcube-cast-btn')) {
      injectCastButton();
    }
  }, 2500);

  // Listen for stream state updates
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'STREAM_STOPPED' && castButton) {
      castButton.classList.remove('streaming');
      castButton.querySelector('.btn-text').textContent = 'Cast to 3D Cube';
    }
  });
})();
